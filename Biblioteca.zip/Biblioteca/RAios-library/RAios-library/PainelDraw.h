//
//  RAPainelDraw.h
//  FURB RA
//
//  Created by Paulo Cesar Meurer on 8/15/11.
//  Copyright 2011 FURB. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PainelDraw : NSObject {
    
}

+ (void)renderPainelWithString:(NSString*)str;
+ (void)renderPainel;

@end
