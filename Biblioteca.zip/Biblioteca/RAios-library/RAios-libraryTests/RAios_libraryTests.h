//
//  RAios_libraryTests.h
//  RAios-libraryTests
//
//  Created by Paulo Cesar Meurer on 11/8/11.
//  Copyright 2011 FURB. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface RAios_libraryTests : SenTestCase {
@private
    
}

@end
