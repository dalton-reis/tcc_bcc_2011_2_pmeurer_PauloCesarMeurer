//
//  RAios_libraryTests.m
//  RAios-libraryTests
//
//  Created by Paulo Cesar Meurer on 11/8/11.
//  Copyright 2011 FURB. All rights reserved.
//

#import "RAios_libraryTests.h"


@implementation RAios_libraryTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in RAios-libraryTests");
}

@end
