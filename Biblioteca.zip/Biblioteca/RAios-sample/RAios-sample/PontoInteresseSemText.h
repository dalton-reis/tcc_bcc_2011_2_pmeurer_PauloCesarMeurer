//
//  PontoInteresseSemText.h
//  FURB RA
//
//  Created by Paulo Cesar Meurer on 9/21/11.
//  Copyright 2011 FURB. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PontoInteresse.h"


@interface PontoInteresseSemText : PontoInteresse {
    
}

@end
