//
//  PontoInteresseSemText.m
//  FURB RA
//
//  Created by Paulo Cesar Meurer on 9/21/11.
//  Copyright 2011 FURB. All rights reserved.
//

#import "PontoInteresseSemText.h"
#import "PainelDraw.h"


@implementation PontoInteresseSemText

- (void)onDraw{
    [PainelDraw renderPainel];
}

@end
