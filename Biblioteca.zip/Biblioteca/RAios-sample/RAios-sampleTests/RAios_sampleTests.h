//
//  RAios_sampleTests.h
//  RAios-sampleTests
//
//  Created by Paulo Cesar Meurer on 11/7/11.
//  Copyright 2011 FURB. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface RAios_sampleTests : SenTestCase {
@private
    
}

@end
