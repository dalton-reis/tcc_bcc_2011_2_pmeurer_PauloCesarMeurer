//
//  RAios_sampleTests.m
//  RAios-sampleTests
//
//  Created by Paulo Cesar Meurer on 11/7/11.
//  Copyright 2011 FURB. All rights reserved.
//

#import "RAios_sampleTests.h"


@implementation RAios_sampleTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in RAios-sampleTests");
}

@end
